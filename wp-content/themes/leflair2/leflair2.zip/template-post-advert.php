<?php
/*
Template Name Posts: Advert Right
*/
?>
<?php get_template_part('templates/content', 'advert'); ?>
