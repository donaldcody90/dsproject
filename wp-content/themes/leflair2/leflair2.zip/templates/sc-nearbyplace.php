<div class="near_by_place row">
<div class="col-md-4 col-sm-4" id="near-by-place-detail">
	<?php 
		echo get_theme_option('location-text');
	/*<div class="near-location-info">
		<ul>
		<li class="right">Restaurants</li>
		<li class="left">1 km</li>
		</ul>
		<span>Born Hommie</span>
	</div>
	
	<div class="near-location-info">
		<ul>
			<li class="right">Coffee</li>
			<li class="left">2 km</li>
		</ul>
		<span>Brakers Basket</span>
	</div>

	<div class="near-location-info">
		<ul>
			<li class="right">Bars</li>
			<li class="left">3.5 km</li>
		</ul>
		<span>Black Current Bar</span>
	</div>

	<div class="near-location-info">
		<ul>
			<li class="right">Groceries</li>
			<li class="left">2.5 km</li>
		</ul>
		<span>Perigee Store</span>
	</div>


	<div class="near-location-info">
		<ul>
			<li class="right">Parks</li>
			<li class="left">1.5 km</li>
		</ul>
		<span>Saint Edgebasten Park</span>
	</div>

	<div class="near-location-info">
		<ul>
			<li class="right">Schools</li>
			<li class="left">2 km</li>
		</ul>
		<span>DPS School</span>
	</div>
	
	<div class="near-location-info">
		<ul>
			<li class="right">Shopping</li>
			<li class="left">4.5 km</li>
		</ul>
		<span>Himalaya Shopping Mall</span>
	</div>


	<div class="near-location-info">
		<ul>
			<li class="right">Entertainment</li>
			<li class="left">1.5 km</li>
		</ul>
		<span>Red Carpet Cinema</span>
	</div>

	<div class="near-location-info">
		<ul>
			<li class="right">Errands</li>
			<li class="left">3 km</li>
		</ul>
		<span>Bank for Baroda</span>
	</div>

	<div class="near-location-info">
		<ul>
			<li class="right">University</li>
			<li class="left">0.5 km</li>
		</ul>
		<span>Gujarat University</span>
	</div>
	*/ ?>
</div>
<div class="col-md-8 col-sm-8 near-location-map">
		<img src="<?php echo get_theme_option('location-map','url'); ?>">
</div>
</div>