<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>

		<title>Leflair Vietnam - Đại tiệc hàng hiệu</title>

		<!-- General META -->
		<meta charset="utf-8">
		<meta http-equiv="Content-type" content="text/html;charset=UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		

		<meta name="description" content="Mua sắm sản phẩm thời trang và mỹ phẩm làm đẹp từ những thương hiệu hàng đầu thế giới. Cam kết chính hãng. Ưu đãi hàng hiệu độc quyền">
		<meta name="keywords" content="leflair, leflair.vn, leflair vietnam, hàng hiệu, hang hieu, private sales, private sale, thời trang, thoi trang, mỹ phẩm, my pham, thương hiệu quốc tế, thuong hieu quoc te, ưu đãi độc quyền, uu dai doc quyen ">

		
		<!--Application CSS Files-->
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/dropkick.css" />
		<link rel="stylesheet" href="css/select.min.css" />
		<link rel="stylesheet" href="css/loading-bar.min.css" />
		<link rel="stylesheet" href="css/menu.css" />
		<link rel="stylesheet" href="css/sidebar.css" />
		<link rel="stylesheet" href="css/application.min.css" />
		
		
		<!-- Criteo tag -->
		<script type="text/javascript" src="//static.criteo.net/js/ld/ld.js" async="true"></script>

		<script async="" src="//static.hotjar.com/c/hotjar-134114.js?sv=5"></script>
		<link rel="manifest" href="https://www.leflair.vn/aimtell-manifest.json">
	
	</head>