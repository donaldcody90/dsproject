<div class="footer">
		<div class="container">
			<div class="row">
				<div class="footer-wrapper">
					<div class="new_logo">
						<center>
						<a href="<?php echo get_home_url() ?>">
							 <img src="<?php echo get_theme_option('new_logo','url'); ?>" alt="logo" />
						</a>
						</center>
					</div>
					<?php echo get_theme_option('copyright-text'); ?>
					<div class="social_icon">
						<a href="" ><img src="assets/img/fb_icon.png" /></a>
						<a href="" ><img src="assets/img/twitter_icon.png" /></a>
						<a href="" ><img src="assets/img/in_icon.png" /></a>
						<a href="" ><img src="assets/img/instagram_icon.png" /></a>
						<a href="" ><img src="assets/img/g+_icon.png" /></a>
					</div>
				</div>
			</div>
		</div>
</div>